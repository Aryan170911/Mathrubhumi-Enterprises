# Mathrubhumi Website Asset Pack

Web-ready image exports and supporting source assets for the Mathrubhumi Enterprises profile.

## Contents

- `images/` — semantically named WebP versions of all 17 profile images, plus a reusable SVG blueprint pattern.
- `originals/` — original PNG files (`image1.png` through `image17.png`) and the print-profile background PNG.
- `manifest.json` — filenames, source dimensions, descriptions, alt text and file sizes.
- `preview.html` — local visual index of the web-ready images.
- `site-starter.css` — brand color tokens and an optional blueprint background class.
- `source_profile.md` — supplied source profile.
- `source_image_descriptions.md` — image catalog from the accompanying asset bundle.

Images are exported as WebP at quality 90 for browser use. Original PNG files are retained unchanged.

## Quick start

Copy the `images/` directory into your site and link `site-starter.css`. Use the `alt_text` values in `manifest.json` as starting points for accessible image descriptions. For a decorative background, mark the element as decorative and use an empty alt value if embedding the SVG as an image.
