# Image descriptions

The first 17 images are extracted from the companion corporate profile DOCX. The final image is the low-contrast blueprint background created for the revised print profile. Descriptions identify visible content; they do not independently verify the claims or ownership represented in an image.

| File | Dimensions | Description |
|---|---:|---|
| [`images/image1.png`](originals/image1.png) | 401 × 401 px | Graphic emblem with a red circular mark and bars crossed by a green rising arrow. |
| [`images/image2.png`](originals/image2.png) | 1680 × 1371 px | Architectural rendering of a large modern industrial building with a glazed lower facade and broad roofline. The PNG has transparent areas around the rendered scene. |
| [`images/image3.png`](originals/image3.png) | 1680 × 711 px | Photograph of an erected multi-bay steel frame with columns, rafters and roof purlins. |
| [`images/image4.png`](originals/image4.png) | 1375 × 990 px | Engineering diagrams comparing pre-engineered building frame arrangements, including clear-span, multi-span and single-slope forms. |
| [`images/image5.png`](originals/image5.png) | 1375 × 590 px | Structural detail drawings showing a crane-supported frame and a joist connection at an end-wall column. |
| [`images/image6.png`](originals/image6.png) | 1275 × 280 px | Dimensioned cross-section of a profiled roof or wall sheet, showing panel ribs and spacing. |
| [`images/image7.png`](originals/image7.png) | 1500 × 796 px | Annotated 3D cutaway of an industrial building, identifying framing, roof and wall components, ventilation, access and mezzanine features. The original uses a dark background. |
| [`images/image8.png`](originals/image8.png) | 1680 × 865 px | 3D structural model of a multi-bay steel building, including primary frames, secondary members, a crane runway and mezzanine area. |
| [`images/image9.png`](originals/image9.png) | 1313 × 738 px | Photograph of an industrial workshop exterior with white metal cladding, large entry bays and a service yard. |
| [`images/image10.png`](originals/image10.png) | 470 × 378 px | Interior photograph of a high-bay workshop with a steel roof, overhead cranes, windows and open floor area. |
| [`images/image11.png`](originals/image11.png) | 313 × 313 px | Close-up photograph of blue industrial forming or pressing equipment with orange safety guards. |
| [`images/image12.png`](originals/image12.png) | 313 × 313 px | CNC cutting equipment with multiple torch heads working over a steel plate. |
| [`images/image13.png`](originals/image13.png) | 239 × 232 px | Photograph of fabrication machinery installed inside a covered industrial workshop. |
| [`images/image14.png`](originals/image14.png) | 325 × 325 px | Blue hydraulic press-brake machine used for forming metal plate. |
| [`images/image15.png`](originals/image15.png) | 325 × 325 px | Blue roll-forming machine with an orange safety frame and a row of forming rollers. |
| [`images/image16.png`](originals/image16.png) | 1370 × 640 px | Aerial view of an industrial construction site and steel-frame building amid surrounding green land. |
| [`images/image17.png`](originals/image17.png) | 1475 × 1730 px | Large collage of client, institutional and partner logos on a white background; individual marks vary in size and resolution. |
| [`images/blueprint_background.png`](images/blueprint_background.png) | 1654 × 2340 px | Subtle, transparent blueprint-style page background created for the revised corporate profile. It combines a faint grid with steel-frame and truss linework concentrated near the page edges. |
