# Mathrubhumi Enterprises (PEB Steel Structures) — Complete Corporate & Technical Profile

## 1. Executive Summary & Corporate Identity

* **Company Name:** Mathrubhumi Enterprises
* **Specialization:** Pre-Engineered Steel Buildings (PEB) & Heavy Structural Steel Fabrication
* **Corporate Status:** Indian Multinational Company
* **Core Philosophy / Tagline:** "Bringing Global Technology to Your Doorstep"
* **Turnkey Scope of Delivery:** Single-point responsibility spanning architectural conceptualization, computerized structural engineering, automated factory fabrication, nationwide logistics, civil foundation coordination, and rapid on-site erection.
* **Annual Manufacturing Capacity:** 20,000 Metric Tonnes Per Annum (MTPA)
* **Plant Covered Workshop Area:** 50,000 Sq. Ft.
* **Finished Goods Staging Yard:** 20,000 Sq. Ft.
* **Operating Footprint:** Pan-India delivery across 18+ states and cross-border international projects (Nepal).
* **Official Web Portal:** [mathrubhumi.site](https://mathrubhumi.site)
* **Direct Contact Line:** +91 87881 38586
* **Official Inquiries Email:** mathrubhuie@gmail.com

---

## 2. Corporate Profile & Capabilities Overview

Mathrubhumi Enterprises is one of India's fastest-growing, high-end specialized structural steel fabrication and construction companies. The organization has established a dominant market presence by delivering cost-effective, precision-engineered steel buildings with predictable lead times and uncompromised structural integrity.

### Turnkey Delivery Model
The company operates an integrated "Civil to Structure" model that eliminates multi-vendor coordination bottlenecks:
1. **Structural Engineering & Detailing:** Dedicated design office creating 3D Building Information Modeling (BIM) structures, joint designs, and automated fabrication drawings.
2. **Factory Manufacturing:** Fully automated shop production in Sampla (Haryana), featuring CNC plasma cutting, automatic submerged arc welding, and high-speed cold roll forming.
3. **Quality & Surface Protection:** 100% non-destructive testing (NDT), SA 2.5 grade shot/sandblasting, and multi-coat anti-corrosive finishing.
4. **Logistics & Material Tracking:** Barcoded piece-mark labeling, protective bundled strapping, and coordinated road transit on dedicated trailers.
5. **Site Installation & Erection:** Specialized mobile erection crews utilizing heavy hydraulic cranes, certified rigging equipment, torque wrenches, and zero-accident safety protocols.

### Market Sectors Catered
* **Heavy Industrial & Manufacturing:** Automotive factories, steel processing sheds, cement processing facilities, and chemical process structures.
* **Logistics & Warehousing:** High-bay e-commerce fulfillment hubs, multi-bay distribution warehouses, container freight stations.
* **Commercial & Retail:** Corporate office complexes, multi-story shopping centers, automotive showrooms, and hypermarkets.
* **Institutional & Educational:** University lecture auditoriums, sports arenas, training academies, and multi-purpose halls.
* **Aviation & Infrastructure:** Wide clear-span aircraft maintenance hangars, air cargo terminals, and metro transit stations.
* **Agro & Cold Chain:** Controlled-atmosphere grain silos, dairy plants, and cold storages using PUF insulated sandwich panels.

---

## 3. Vision, Mission & Core Values

### Our Vision
> "To be recognized as the premier Market Leader for Pre-Engineered Steel Buildings (PEB) and heavy structural systems by providing complete, dependable building steel structure solutions spanning design, manufacturing, supply, and installation."

### Our Mission
> "Guided by our vision, we endeavor to provide the best quality and service in every project. We guarantee on-time delivery, technical excellence, and dependable customer support adhering to the highest national and international safety standards."

### Core Corporate Values
1. **Mutual Respect & Trust for All Employees:** Cultivating an empowered engineering culture where personnel development, health, and continuous safety training are prioritized.
2. **Creative & Innovative Engineering:** Continuously challenging conventional construction techniques through parametric design optimization and value-engineered modular components.
3. **Cohesive Teamwork:** Fostering seamless collaboration between architectural designers, plant fabricators, civil teams, and field erection specialists.
4. **Ethical & Transparent Governance:** Adhering to uncompromising moral conduct, transparent commercial agreements, and enduring client partnerships.
5. **Environmentally Responsible Stewardship:** Standardizing on 100% recyclable green steel, thermal energy-efficient cladding, and resource-efficient manufacturing that minimizes carbon intensity.
6. **Customer-Centric Focus & Responsiveness:** Direct involvement of executive leadership in critical project milestones to ensure client commitments are met on time.

---

## 4. Strategic Operational Pillars

Mathrubhumi Enterprises anchors its daily operations around four disciplined strategic pillars:

| Strategic Pillar | Core Focus | Execution Standard |
| :--- | :--- | :--- |
| **1. Quality Assurance** | Pre-manufacturing quality gates, material testing, and certified welding. | 100% verified Mill Test Certificates; compliance with Indian Standards (IS) and American Institute of Steel Construction (AISC) standards; continuous weld inspection. |
| **2. Engineering Innovation** | Parametric computerized structural engineering and standardized modular details. | Full 3D finite element frame modeling (STAAD.Pro, TEKLA); custom connection detailing tailored to specific floor space and crane requirements. |
| **3. Sustainable Design** | Resource-efficient steel structures minimizing environmental impact. | Use of 100% recyclable structural steel; optimization of member cross-sections to eliminate dead weight; integration of high-performance thermal insulation. |
| **4. Operational Excellence** | Dimensional precision, weight verification, and fast-track execution. | Strict fabrication tolerances (±2 mm); barcoded logistics tracking; hands-on executive management across all major turnkey installations. |

---

## 5. Engineering Advantages of Pre-Engineered Buildings (PEB)

Pre-Engineered Buildings represent a significant engineering evolution over traditional site-welded structural steel:

* **30% Lighter Structural Self-Weight:** Primary rigid frames utilize custom tapered built-up sections where flange and web plate thickness vary along the member length according to the actual bending moment envelope. This eliminates redundant steel in low-stress zones.
* **50% Accelerated Construction Schedules:** Because all cutting, welding, drilling, and painting occur inside a controlled factory concurrent with on-site civil foundation work, total project delivery drops from 20–26 weeks (conventional) to just 6–8 weeks (PEB).
* **30% Lower Overall Capital Cost:** Savings compound through reduced steel tonnage, significantly smaller concrete foundations, minimal on-site skilled labor requirements, and accelerated commercial commissioning.
* **Superior Seismic Ductility:** Lighter building mass drastically reduces earthquake inertia forces ($F = m \cdot a$). Coupled with ductile, bolted moment connections, PEB structures absorb dynamic energy without brittle failure.
* **Predictable & Fixed Budgets:** Fully computerized detailing yields an exact Bill of Quantities (BOQ) with zero material wastage, preventing unexpected budget escalations.
* **Inorganic & Highly Resilient Material:** Structural steel does not warp, rot, crack, or split over time. It is completely non-combustible, impervious to fungal attack, mold, and termites.
* **Superior Green Building Credentials:** Structural steel is 100% recyclable and boasts an industry-wide recycling recovery rate of 68%+, significantly contributing to green building certifications (LEED/IGBC).
* **Factory-Controlled Tolerances:** Robotic and automated submerged arc welding lines eliminate weather-induced defects and manual welder fatigue common in site-built structures.

---

## 6. Comprehensive Technical Comparison: PEB vs. Conventional Steel

| No. | Evaluation Parameter | Mathrubhumi Pre-Engineered Buildings (PEB) | Conventional Structural Steel Buildings |
| :---: | :--- | :--- | :--- |
| **1** | **Structural Self-Weight** | **30% Lighter:** Engineered with tapered built-up plates optimized strictly according to the bending moment envelope. | **Heavy Self-Weight:** Standard hot-rolled sections have uniform depth throughout, carrying redundant dead load in low-stress areas. |
| **2** | **Primary Framing Members** | **Tapered Built-Up Sections:** Flange and web plate dimensions are customized for maximum efficiency and strength. | **Standard Hot-Rolled 'I' Sections:** Fixed dimensions result in excess weight and limited span efficiency. |
| **3** | **Secondary Framing Members** | **Cold-Formed Z & C Purlins:** Lightweight, high-tensile galvanized steel profiles with continuous overlap for strength. | **Hot-Rolled Channels & Angles:** Heavy, ungalvanized steel sections that add substantial dead weight. |
| **4** | **Delivery Lead Times** | **6 to 8 Weeks Average:** Simultaneous foundation work on site and automated shop fabrication in the plant. | **20 to 26 Weeks Average:** Protracted timeline dependent on sequential on-site fabrication and manual labor. |
| **5** | **Foundation Design & Cost** | **Lightweight Footings:** Reduced structural dead weight drastically lowers concrete and excavation requirements. | **Heavy, Expensive Foundations:** Massive pile or raft foundations needed to support excessive structural dead weight. |
| **6** | **Erection Cost & Schedule** | **Accurately Known & 20–30% Cheaper:** Fast bolted field erection with minimal field labor requirements. | **Unpredictable & 20%+ Higher:** High field labor costs, prolonged crane rentals, and weather-dependent productivity. |
| **7** | **Erection Simplicity** | **Systematic Bolted Assembly:** Factory-punched holes and numbered piece-marks allow step-by-step modular erection. | **Extensive Field Welding & Labor:** Slow on-site cutting, manual fit-up, and weather-vulnerable field welding. |
| **8** | **Seismic Performance** | **High Ductility & Low Mass:** Flexible moment frames absorb dynamic seismic energy safely with minimal base shear. | **Rigid Heavy Mass:** Stiff, heavy structures generate high inertial forces, performing poorly in active seismic zones. |
| **9** | **Overall Project Cost** | **~30% Lower Overall Expenditure:** Significant savings across raw materials, foundations, and rapid commissioning. | **Substantially Higher Cost:** Elevated price per square meter due to excessive steel tonnage and manual labor. |
| **10** | **Architectural Versatility** | **Aesthetic & Easily Expandable:** Clean lines, large clear spans, contemporary fascias, and modular future expansion. | **Difficult to Modify:** Architectural features and structural alterations involve high cost and complex field modifications. |

---

## 7. Structural Framing Systems & Engineering Geometries

Mathrubhumi PEB structures are engineered in multiple standard framing geometries to address diverse spatial layouts, functional crane clearances, and clear span requirements:

### Standard Framing Configurations
1. **Clear Span (CS):**
   * **Practical Width Range:** 6 m to 30 m+ unobstructed width.
   * **Engineering Feature:** Completely column-free interior floor area.
   * **Key Applications:** E-commerce distribution hubs, sports arenas, aircraft hangars, event pavilions.
2. **Multi-Span '1' (MS-1):**
   * **Practical Width Range:** 24 m to 48 m maximum width.
   * **Engineering Feature:** Continuous rigid frame supported by a single center interior column.
   * **Key Applications:** Dual-bay industrial manufacturing plants, assembly facilities.
3. **Multi-Gable (MG):**
   * **Practical Width Range:** 24 m to 60 m maximum width.
   * **Engineering Feature:** Multi-ridge roof geometry providing efficient rainwater runoff over wide footprints.
   * **Key Applications:** Expansive chemical plants, textile processing mills, large industrial sheds.
4. **Multi-Span '2' (MS-2):**
   * **Practical Width Range:** 36 m to 72 m maximum width.
   * **Engineering Feature:** Multi-column interior supports with optimized modular grid spacing.
   * **Key Applications:** Heavy engineering workshops requiring flexible machine corridors.
5. **Single Slope (SS):**
   * **Practical Width Range:** 3 m to 18 m maximum width.
   * **Engineering Feature:** Unidirectional roof slope for targeted water drainage away from adjacent structures.
   * **Key Applications:** Lean-to building extensions, side utility corridors, administrative office annexes.
6. **Fixed Base System (FBSR):**
   * **Practical Width Range:** 48 m to 96 m maximum width.
   * **Engineering Feature:** Heavy fixed-base moment connections engineered for extreme spans and heavy dynamic loads.
   * **Key Applications:** Mega industrial plants, heavy fabrication mills, multi-bay logistics campuses.

### Material Handling & Crane System Integration
* **Top-Running Bridge Cranes:** Primary columns are designed with reinforced crane brackets, runway beams, and surge bracing to support overhead electric traveling (EOT) cranes ranging from 5 MT to 50+ MT capacity.
* **Crane Runway Hardware:** Precision-aligned crane rail assemblies, end stops, safety walkways, and maintenance ladders.
* **Composite Mezzanine Floor Systems:** Heavy primary mezzanine beams and secondary cold-formed joists support galvanized profiled metal decking for cast-in-place reinforced concrete floor slabs, enabling multi-tier industrial office or storage facilities.

---

## 8. High-Performance Roof & Wall Cladding Systems

Mathrubhumi manufactures roll-formed metal cladding designed for high load capacity, architectural aesthetics, and long-term weather tightness.

### Hi-Rib Profile Sheeting Specifications
* **Profile Depth:** 32 mm high rib profile providing superior moment of inertia and water-shedding capacity.
* **Rib Pitch / Spacing:** 200 mm (±3 mm) center-to-center rib pitch with reinforcing stiffener flutes between main ribs.
* **Effective Coverage Width:** 1000 mm to 1060 mm effective lay width per panel.
* **Base Metal Thickness (BMT):** Available from 0.30 mm to 0.80 mm thickness depending on span and structural load criteria.
* **Material Grades:**
  * Pre-Painted Galvalume (PPGL) conforming to ASTM A792M Grade D / IS 14246 (55% Aluminum, 43.4% Zinc, 1.6% Silicon alloy coating, AZ150 g/m²).
  * Pre-Painted Galvanized Iron (PPGI) conforming to IS 277 / IS 14246 (Zinc coating mass 120–275 g/m²).
* **Anti-Capillary Siphon Groove:** Precision-engineered reverse groove along the overlapping edge that acts as an air siphon break, preventing capillary water leakage during heavy monsoon winds.
* **Coating Durability:**
  * **Primer:** High-corrosion-resistant epoxy primer (5 microns back / 5 microns front).
  * **Top Finish:** Regular Modified Polyester (RMP), Silicon Modified Polyester (SMP), or Polyvinylidene Fluoride (PVDF/Kynar 500) offering 25+ years of UV stability, color retention, and chalk resistance.

---

## 9. Architectural Anatomy of a Pre-Engineered Building

A Mathrubhumi Pre-Engineered Building is a synchronized structural assembly comprised of four key component directories:

### Directory 1: Primary Structural Framing
* **Rigid Frame Columns:** Heavy tapered or uniform built-up H-sections carrying primary vertical and lateral loads down to foundations.
* **Rigid Frame Rafters:** Tapered built-up roof beams spanning between columns and connected via high-strength moment end-plate connections.
* **Top-Running Crane Beams:** Specially sized longitudinal beams supporting overhead bridge crane travel.
* **Crane Runway Brackets:** Heavy gusseted brackets welded to primary column flanges to transfer dynamic crane reactions.
* **Composite Mezzanine Beams:** Structural steel beams designed with shear connectors for composite action with concrete floor slabs.
* **Lean-To Building Frames:** Rafters and posts extending outward from the main building to create sheltered utility annexes.

### Directory 2: Secondary Cold-Formed Framing & Bracing
* **Cold-Formed Z-Purlins:** Continuous cold-rolled Z-shaped profiles supporting roof panels, overlapping at interior frames to act as continuous beams.
* **Sidewall & Endwall Girts:** C or Z-shaped horizontal wall framing sections supporting exterior metal siding.
* **Eave Struts:** Heavy cold-formed or built-up structural sections positioned at the roof-wall intersection, transferring longitudinal wind forces.
* **Diagonal Rod & Cable Bracing:** Tension rod bracing in roof and sidewall bays that transfers longitudinal wind and crane braking loads to the foundations.
* **Flange Bracing & Sag Rods:** Angle bracing connecting purlins and girts to inner column/rafter flanges to prevent lateral-torsional buckling.
* **Mezzanine Deck Joists:** Closely spaced secondary floor beams supporting the metal decking sheet.

### Directory 3: Sheeting, Weatherproofing & Envelope
* **Hi-Rib Roof Panels:** Primary weather envelope spanning across roof purlins.
* **High-Tensile Wall Cladding:** Vertical or horizontal exterior profile panels with aesthetic color finishes.
* **Polycarbonate Skylights:** High-impact translucent roof panels transmitting natural daylight (90% light transmission, UV protected).
* **Parapet Fascia & Curved Eaves:** Architectural wall extensions concealing roof slopes, combined with curved transition flashings.
* **High-Capacity Eave Gutters & Downspouts:** Cold-formed galvanized or color-coated perimeter drainage channels and downpipes.
* **Corner Trims & Ridge Caps:** Formed sheet metal flashings sealing building corners, ridges, and transitions.

### Directory 4: Architectural Access & Environmental Hardware
* **Motorized Roll-Up Doors:** Heavy-gauge interlocking slat steel shutters for commercial cargo and vehicle ingress.
* **Double Sliding Access Doors:** Large steel-framed sliding doors engineered for oversized equipment access.
* **Personnel Egress Doors:** Fire-rated single and double leaf walk doors with panic hardware.
* **Industrial Air Louvers:** Stationary weather-proof steel louvers providing continuous fresh air ventilation while excluding dust and rainwater.
* **Roof Platforms & Handrails:** Safe structural maintenance platforms around ventilation equipment.
* **Safety Cage Ladders:** External galvanized steel access ladders equipped with full safety cages.

---

## 10. Engineering Design Facility ("The Knowledge Hub")

Mathrubhumi's engineering center is staffed by certified structural and civil engineers equipped with high-performance workstations and licensed international engineering software:

### Software Applications
* **STAAD.Pro V8i:** 3D finite element frame modeling, space frame analysis, and stress optimization under static, wind, and dynamic seismic loads.
* **TEKLA Structures (BIM 3D):** Full 3D structural modeling, clash detection, joint connection detailing, automated general arrangement (GA) drawings, and CNC fabrication output.
* **Metal Building Software (MBS):** Specialized parametric design system optimizing PEB tapered frames, secondary purlin lines, and comprehensive bills of materials.
* **AutoCAD 2021:** Architectural planning, erection sequences, civil foundation layout drawings, and anchor bolt setting plans.
* **BOCAD / STRUCAD:** Advanced joint detailing for complex heavy structural steel interfaces.

### Governing Design Standards & Engineering Codes

| Engineering Domain | Indian Standard (IS) Code | International / American Standard |
| :--- | :--- | :--- |
| **Structural Steel Design** | **IS 800:2007** (Limit State Design / Working Stress Design) | **AISC 360-16** (Specification for Structural Steel Buildings) |
| **Metal Building Specifications**| — | **MBMA 2012** (Metal Building Systems Manual) |
| **Cold-Formed Light Gauge Steel**| **IS 801:1975** (Use of Cold-Formed Light Gauge Sections) | **AISI S100** (North American Spec for Cold-Formed Steel) |
| **Dead & Imposed Design Loads** | **IS 875 (Part 1 & 2):1987** | **ASCE 7-16** (Minimum Design Loads for Buildings) |
| **Wind Load Calculations** | **IS 875 (Part 3):2015** (Up to 55 m/s basic wind speeds) | **MBMA / ASCE 7-16** |
| **Earthquake-Resistant Design** | **IS 1893 (Part 1):2016** (Seismic Zones II, III, IV, V) | **IBC 2018 / AISC 341** (Seismic Provisions for Steel) |
| **Structural Welding Standards** | **IS 816 / IS 9595** (Arc Welding in General Building) | **AWS D1.1 / D1.1M** (Structural Welding Code – Steel) |

---

## 11. 10-Stage Precision Shop Fabrication Workflow

Every structural component undergoes a controlled 10-stage manufacturing sequence inside the Sampla facility:

```
[01. Raw Material Inward] ──► [02. CNC Profile Cutting] ──► [03. Fit-Up & Tack Assembly] ──► [04. SAW Welding Line]
                                                                                                    │
[08. Anti-Corrosive Paint] ◄── [07. Surface Sandblasting] ◄── [06. Quality Audit & NDT] ◄── [05. Secondary Cold Roll]
         │
         ▼
[09. Piece-Mark Tagging] ──► [10. Scheduled Site Dispatch]
```

1. **Stage 01 — Raw Material Inward & Testing:** High-grade structural steel plates (E250 / E350 grade conforming to IS 2062 and ASTM A572 Grade 50) and galvanized coils arrive at the yard. Physical inspection, thickness verification, Mill Test Certificate (MTC) audits, and ultrasonic testing verify laminations and chemical composition.
2. **Stage 02 — CNC Profile Cutting:** Plates are placed on automated CNC multi-torch plasma and oxy-fuel cutting beds. Computerized nesting software minimizes material scrap while delivering clean, localized narrow-kerf cuts up to 25 mm thickness.
3. **Stage 03 — Fit-Up & Tack Assembly:** Flange and web plates are aligned in dedicated hydraulic assembly jigs. Tack welds secure components in strict alignment with shop drawings, controlling camber, sweep, and squareness.
4. **Stage 04 — Submerged Arc Welding (SAW):** Assembled tapered H-beams pass through continuous twin-arc Submerged Arc Welding lines. Controlled flux shielding and 15° torch angles deliver deep root penetration and continuous, high-strength structural fillet welds.
5. **Stage 05 — Secondary Cold Roll Forming:** High-tensile pre-galvanized steel strips (min. 345 MPa yield) are continuously profiled into Z and C purlins. In-line hydraulic punching dies stamp bolt holes and connection slots at computerized intervals.
6. **Stage 06 — Quality Audit & NDT Testing:** Certified QC inspectors conduct 100% visual weld inspection, dimensional audits, Dye-Penetrant Testing (DPT) on critical moment connections, and Ultrasonic Testing (UT) on butt welds.
7. **Stage 07 — Surface Preparation & Sandblasting:** Structural steel components undergo centrifugal shot/sandblasting to Swedish Standard SA 2.5. The process removes 100% of mill scale, rust, and surface contaminants, establishing a clean 40–50 micron anchor profile.
8. **Stage 08 — Protective Anti-Corrosive Coating:** Structural steel receives an airless spray application of high-build zinc-phosphate primer (75 microns DFT). For aggressive environments, an aliphatic polyurethane (PU) or epoxy intermediate/topcoat is applied.
9. **Stage 09 — Piece Marking & Bundling:** Every component is hard-stamped and labeled with a unique barcoded piece-mark that cross-references the erection drawing. Members are bundled with protective wood dunnage and heavy steel strapping.
10. **Stage 10 — Scheduled Site Dispatch:** Coordinated loading onto long-bed articulated trailers ensures safe road transit and phased delivery to erection sites in exact installation sequence.

---

## 12. Quality Assurance & Non-Destructive Testing (NDT) Protocols

Mathrubhumi Enterprises operates an ISO 9001 certified manufacturing process. Quality gates govern every fabrication step:

* **Visual Inspection (100%):** All welded joints are visually checked for weld profile, undercut, porosity, overlap, and crack absence per AWS D1.1.
* **Dimensional Inspection (100%):** Laser and calibrated steel tape audits verify length, width, depth, squareness, hole spacing, and connection bolt pitch within ±2 mm allowable tolerances.
* **Liquid Dye-Penetrant Testing (DPT):** Conducted on all moment connection welds and lifting lug joints to identify surface-breaking cracks or discontinuities.
* **Ultrasonic Testing (UT):** Performed on all full-penetration butt welds in tension flanges and critical crane runway girders to detect internal inclusions or lack of fusion.
* **Coating Thickness Audit:** Magnetic Dry Film Thickness (DFT) gauges verify that primer and paint layers achieve the required thickness uniformly across all faces.

---

## 13. Manufacturing Plant Infrastructure & Capacity

* **Plant Location:** Khewat No. 254, Khataoni No. 263, Kila No. 151/121 min, Sampla-Beri Road, Sampla, Rohtak, Haryana – 124501
* **Covered Workshop Fabrication Area:** 50,000 Sq. Ft.
* **Open Finished Goods Yard:** 20,000 Sq. Ft. for pre-assembly staging, sandblasting, and dispatch.
* **Annual Manufacturing Capacity:** 20,000 Metric Tonnes (MT) per annum.
* **Heavy Material Handling Fleet:** 7 units of Electric Overhead Traveling (EOT) cranes (up to 25 MT lift capacity) and mobile Hydra cranes ensuring safe material transfer.
* **Auxiliary Plant Facilities:**
  * Double-story administrative complex housing project management and QC offices.
  * Dedicated in-house tool room for die sharpening, machine tooling, and maintenance.
  * Consumables warehouse holding certified welding wires, flux, bolts, and paints.
  * On-site staff accommodation quarters enabling round-the-clock shift operations.
  * In-house testing laboratory equipped for mechanical tension, bend, and hardness testing.

---

## 14. Core Production Machinery Fleet

Mathrubhumi's Sampla facility operates advanced automated machine lines:

### 1. CNC Multi-Torch Plasma & Flame Cutting System
* **Annual Capacity:** 10,000 MTPA plate cutting output.
* **Plate Thickness Capability:** 1.6 mm to 25 mm high-tensile structural steel plates.
* **Daily Output Rate:** 20 MT per day on dual shifts.
* **Power Source & Technology:** Hypertherm Powermax 125 plasma cutting system.
* **Operating Mechanism:** High-velocity plasma jet melting steel at 1500°C with automated CNC nesting for narrow kerfs and minimal heat distortion.

### 2. Automatic Heavy H-Beam Submerged Arc Welding (SAW) Line
* **Beam Depth Capability:** 200 mm minimum to 1800 mm maximum web depth.
* **Flange Width Capability:** 150 mm minimum to 500 mm maximum flange width.
* **Flange Thickness Range:** 4 mm to 32 mm steel plate thickness.
* **Maximum Single-Piece Length:** Up to 13,000 mm (13 meters) length.
* **Welding Process:** Dual-wire automatic submerged arc welding system with 15° torch tilt for deep root fusion and uniform weld bead geometry.

### 3. HV Series High-Speed Roll Forming Machine
* **Coil Thickness Range:** 0.35 mm to 0.80 mm Base Metal Thickness (BMT).
* **Effective Coil Width:** 1220 mm feed strip width.
* **Maximum Line Speed:** Up to 20 meters per minute continuous forming.
* **Uncoiler Capacity:** 6 Metric Ton (MT) motorized hydraulic decoiler.
* **Material Processed:** ASTM A792M Grade D pre-painted Galvalume & galvanized steel coils.

### 4. Heavy-Duty Hydraulic Press Brake
* **Bending Force Capacity:** 1500 Ton maximum hydraulic pressing force.
* **Maximum Bed Length:** 3150 mm working length.
* **Distance Between Frames:** 3000 mm clear frame clearance.
* **Operational Scope:** Cold-bending heavy structural connection plates, perimeter gutters, curved architectural eaves, and parapet fascias.

### 5. Quick-Interchange CNC C & Z Purlin Roll Forming & Punching Line
* **Strip Thickness Range:** 1.5 mm to 3.5 mm high-tensile galvanized steel.
* **Web Dimension Range:** 100 mm to 350 mm web height.
* **Flange Dimension Range:** 30 mm to 100 mm flange width.
* **Operating Line Speed:** Up to 20 meters per minute.
* **Decoiler & Automation:** 5 MT automatic decoiler with precision leveling rolls and programmable multi-hole hydraulic punching (±2 mm hole center tolerance).

---

## 15. Engineered Building Accessories Portfolio

Mathrubhumi manufactures and supplies a comprehensive range of structural accessories:

1. **Rotary Turbo Ventilators:**
   * **Material & Construction:** High-grade Alloy 8011 aluminum, 42 aerodynamic curved vanes, 2 mm thick base mounting plate.
   * **Dimensions:** 600 mm throat/neck diameter, 750 mm turbine sphere diameter, 425 mm height.
   * **Operating Principle:** Natural thermal convection and wind velocity drive silent, maintenance-free rotation with zero electrical power consumption.
2. **Continuous Ridge Ventilators:**
   * **Material & Finish:** Cold-rolled color-coated galvanized steel, aluminum, or FRP.
   * **Dimensions:** Throat widths from 600 mm, 725 mm, to 925 mm; lengths in 1000 mm modules.
   * **Features:** 100% waterproof, gravity hot-air and fume exhaust, tamper-proof internal baffles.
3. **PUF / EPS Insulated Sandwich Panels:**
   * **Wall Panels Thickness:** 40, 50, 60, 80, 100, 120, and 150 mm.
   * **Roof Panels Thickness:** 30, 40, 50, 60, 80, 100, 120, and 150 mm.
   * **Performance:** Rigid polyurethane foam (PUF) core with closed-cell density of 40 ± 2 kg/m³; superior thermal insulation for sub-zero cold storages, cleanrooms, and conditioned manufacturing.
4. **Industrial Steel Louvers:**
   * **Design:** Custom-length modular steel frames with fixed or adjustable weather-baffle blades.
   * **Features:** Allows free airflow ventilation while preventing rainwater ingress and dust penetration; maintenance-free factory finish.
5. **Self-Drilling Screws & Fasteners:**
   * **Material & Size:** Case-hardened carbon steel (silver ruspert / galvanized coating) and Grade 304/316 stainless steel; lengths from 6.0 mm to 130 mm.
   * **Weatherproofing:** Integrated bonded EPDM vulcanized washers ensuring watertight seal and high pull-out load resistance.
6. **High-Tensile Structural Nut & Bolts:**
   * **Material & Grade:** High-tensile mild steel (MS) and stainless steel (SS) Grade 8.8 and 10.9 structural bolts with matching hardened heavy hex nuts and washers.
   * **Applications:** Primary moment frame splice joints, column base plate connections, and crane runway joints subjected to dynamic vibration.
7. **Motorized Rolling Shutters:**
   * **Construction:** Interlocked Galvalume, galvanized steel, or aluminum profile slats (available in insulated and non-insulated designs).
   * **Drive Mechanism:** Heavy-duty side-mount electric motors with manual chain override and remote automation.
8. **Galvanized Cable Trays:**
   * **Types:** Perforated and ladder-type cable trays manufactured in galvanized steel, stainless steel, and aluminum.
   * **Applications:** Heavy electrical power distribution, control raceways, instrumentation, and telecommunication cabling.
9. **Fire-Fighting Safety Integration:**
   * **Provisions:** Engineered structural brackets for dry/wet sprinkler piping, internal hydrant drops, foam monitors, and emergency egress routing integrated into structural steel members.

---

## 16. Landmark Completed Projects Portfolio

Mathrubhumi Enterprises has successfully delivered over 500,000+ square meters of covered industrial space:

| No. | Project Location | Facility Typology | Structural Scope & Technical Highlights |
| :---: | :--- | :--- | :--- |
| **1** | **Noida Sector-79, Uttar Pradesh** | Logistics & Warehousing Hub | High-capacity clear-span distribution warehouse designed with wide clear heights for automated racking systems. |
| **2** | **Gurugram, Haryana** | Corporate Commercial Complex | Contemporary curved architectural steel building with integrated curtain wall glazing and premium composite cladding. |
| **3** | **Firozpur, Punjab** | Industrial Storage Shed | Multi-bay structural steel storage facility delivered on a fast-track erection schedule. |
| **4** | **Dhangadi, Nepal** | Cross-Border Manufacturing Plant | Turnkey cross-border industrial processing complex featuring heavy clear spans and international customs logistics. |
| **5** | **Kadappa, Andhra Pradesh** | Heavy Industrial Processing Plant | Heavy structural steel manufacturing shed engineered to support process piping and crane runway beams. |
| **6** | **Karnal, Punjab** | Agro Storage & Warehouse Facility | High-capacity agricultural commodity warehouse engineered for bulk grain storage and optimized natural ventilation. |
| **7** | **Jhajjar, Haryana** | Heavy Equipment Manufacturing Shed | Industrial machinery assembly facility featuring high eave heights and integrated EOT crane runways. |
| **8** | **Sonipat, Haryana** | Industrial Processing Facility | Multi-bay processing plant with integrated two-story composite mezzanine office facilities. |
| **9** | **Okhla, New Delhi** | Multi-Bay Urban Industrial Complex | High-density urban manufacturing warehouse engineered within tight municipal boundary constraints. |
| **10** | **Belagavi, Karnataka** | Heavy Structural Steel Shed | Industrial manufacturing shed engineered for high seismic zone compliance and heavy wind load resistance. |
| **11** | **Multi-Acre Integrated Campus** | Mega Industrial Campus Under Erection | Extensive multi-bay structural steel development spanning multiple hectares, demonstrating rapid large-scale field erection. |

---

## 17. Prestigious Clients & Institutional Partners

Mathrubhumi Enterprises has been selected by major Indian public sector undertakings, multinational corporations, diplomatic missions, and global humanitarian agencies:

### Infrastructure, Power & Energy
* **Indian Oil Corporation Limited (IOCL)**
* **Meghalaya Energy Corporation Limited (MeECL)**
* **Nepal Electricity Authority (NEA)**
* **SAEL Power**
* **GreenCell Mobility**
* **National Structure and Engineering (NSE)**
* **KEC International Limited**

### Cement, Steel & Industrial Manufacturing
* **Dalmia Bharat Limited**
* **Star Cement**
* **Bridge & Roof Co. (India) Limited** (A Government of India Enterprise)
* **Century Plyboards**
* **Balaji Polymers**
* **Riddhi Siddhi Cement**
* **Kamala TMT Steel**

### Automotive & Heavy Transport
* **Air India**
* **Mazda Motors**
* **MG Motors**
* **Great Wall Motor (GWM)**

### Commercial, Pharmaceuticals & Consumer
* **Suez Water Technologies**
* **Unilever**
* **Haldiram's**
* **Hyatt Regency**
* **Quest Pharmaceuticals**
* **Arya Pharmalab Pvt. Ltd.**
* **Unitech Group**
* **Casino Pride**
* **United Telecoms Limited (UTL)**
* **Bohra Group**
* **Maruti Textile**

### Diplomatic & Humanitarian Agencies
* **British Embassy**
* **United Nations Children's Fund (UNICEF)**
* **United Nations Office for Project Services (UNOPS)**
* **Nepal Red Cross Society (NRCS)**
* **ISKCON Nepal**

---

## 18. Corporate Office Network & Directory

Mathrubhumi Enterprises maintains administrative, design, and manufacturing centers across India:

### 1. Registered Head Office (Bihar)
* **Entity:** Mathrubhumi Enterprises
* **Address:** Prabhunath Nagar, Chapra, Bihar – 841301, India
* **Operational Scope:** Central corporate administration, regional government liaison, and institutional relations.

### 2. Corporate & Engineering Design Hub (NCR)
* **Entity:** Mathrubhumi Enterprises
* **Address:** 2nd Floor, Plot No. 588, Udyog Vihar Phase V, Gurugram, Haryana – 122008, India
* **Operational Scope:** Central engineering design office, BIM detailing hub, commercial sales, and project management.

### 3. State-of-the-Art Manufacturing Plant (Haryana)
* **Entity:** Mathrubhumi Heavy Fabrication Works
* **Address:** Khewat No. 254, Khataoni No. 263, Kila No. 151/121 min, Sampla-Beri Road, Sampla, Rohtak, Haryana – 124501, India
* **Operational Scope:** 50,000 sq. ft. heavy structural fabrication, CNC cutting, automated welding, roll forming, and logistics dispatch.

### 4. Official Contact Channels
* **Telephone Support:** +91 87881 38586
* **Official Corporate Email:** [mathrubhuie@gmail.com](mailto:mathrubhuie@gmail.com)
* **Official Website:** [mathrubhumi.site](https://mathrubhumi.site)

---

## 19. Brand Closing Commitment

> **"Mathrubhumi Enterprises (PEB Steel Structures) — Engineered for Strength, Delivering Precision Nationwide. Built for the Future."**
